import pandas as pd
import numpy as np


grades = {2018: [85, 73, 80, 64],
          2019: [60, 80, 58, 96],
          2020: [90, 64, 74, 87],
          2021: [85, 83, 79, 82],
          2022: [92, 93, 100, 83],
          'Subjects': ['Math', 'Science', 'English', 'Arts']}
grades_df = pd.DataFrame(grades)

index_df = grades_df.set_index('Subjects')
print("\nIndex Data Frame\n", index_df)

# Question 1
index_df[2019] = index_df[2019] + 3
print("\n Updated 2019 Data Frame\n", index_df)

# Question 2
index_df.at['Math', 2021] = 95
print("\n Updated 2021 Math Data Frame\n", index_df)

# Question 3
index_df['Mean'] = index_df.mean(axis=1)
index_df = index_df.sort_values(by='Subjects', ascending=True)
print("\n Alphabetical Mean Data Frame\n", index_df)

# Question 4
min_grade_2020 = index_df[2020].min()
print("\n Lowest Grade 2020:\n", min_grade_2020)

# Question 5
index_df_drop_rows = index_df.drop(['Science', 'Arts'])
print("\n Lowest Grade 2020:\n", index_df_drop_rows)

# Question 6
index_df_drop_cols = index_df.drop(2021, axis=1)
print("\n Lowest Grade 2020:\n", index_df_drop_cols)
