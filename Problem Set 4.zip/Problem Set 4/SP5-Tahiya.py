import pandas as pd
import numpy as np


iris = pd.read_csv('Problem_Set_4/IrisData.csv')
iris_clean = iris.dropna()

# Question 1
species_count = iris_clean['species'].value_counts()
print(f"\nMost frequent species: {species_count.idxmax()}\nFrequency: {species_count.min()}\n")

# Question 2
dup_mask = iris_clean.duplicated()
print("\nDuplicated Rows:\n", dup_mask)

# Question 3
filtered = iris_clean[(iris_clean['sepal_length'] > 5) & (iris_clean['sepal_width'] > 3)]
print("\nFilters Applied: Sepal Length > 5 and Sepal Width > 3\n", filtered)

# Question 4
highest = iris_clean.idxmax()
print("\nIndexes of Highest of Each Column Value\n", highest)

# Question 5
filter_numeric = iris_clean.select_dtypes(include=[np.number])
corr_matrix = filter_numeric.corr()
cov_matrix = filter_numeric.cov()
print(f"\nCorr Matrix {corr_matrix}\n\nCov Matrix {cov_matrix}\n")
print(f"\nThe most correlated column to sepal_length is petal_length")
