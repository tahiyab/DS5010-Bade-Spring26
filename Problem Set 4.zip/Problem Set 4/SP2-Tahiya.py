import pandas as pd


# Question 1
grades = {2018: [85, 73, 80, 64],
          2019: [60, 80, 58, 96],
          2020: [90, 64, 74, 87],
          2021: [85, 83, 79, 82],
          2022: [92, 93, 100, 83],
          'Subjects': ['Math', 'Science', 'English', 'Arts']}
grades_df = pd.DataFrame(grades)

# Question 2
index_df = grades_df.set_index('Subjects')
print("\nIndex Data Frame\n", index_df)

# Question 3
label_df = index_df.loc[['Math', 'English']]
print("\nLabel Data Frame\n", label_df)

# Question 4
slice_df = index_df.loc['Math':'English', 2019:2021]
print("\nSlice Data Frame\n", slice_df)

# Question 5
pos_df = index_df.iloc[[0, 2], :]
print("\nPosition Data Frame\n", pos_df)

# Question 6
pos_slice_df = index_df.iloc[0:3, 1:4]
print("\nPosition and Slice Data Frame\n", pos_slice_df)
