import pandas as pd


iris = pd.read_csv('Problem_Set_4/IrisData.csv')

# Question 1
first = iris.head(10)
last = iris.tail(10)
print("\nFirst and Last 10 Rows of Iris Dataset:\n", first, "\n", last)

# Question 2
iris.info()
print("\nStatistical Metrics:\n", iris.describe())

# Question 3
null_mask = iris.isnull().any(axis=1)
print("\nRows with Missing Values:\n", iris[null_mask])

# Question 4
iris_clean = iris.dropna()
print("\nRow Count:\n", len(iris_clean))
