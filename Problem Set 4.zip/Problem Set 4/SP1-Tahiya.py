import pandas as pd
import numpy as np


# Question 1
string_list = ['Hola', 'Hi', 'Habari', 'Hallo', 'Hej']
string_df = pd.DataFrame(string_list, columns=['StringData'])

# Question 2
arr = np.random.randint(0, 101, size=5)
arr_df = pd.DataFrame(arr, columns=['RandomIntegers'])

# Question 3
values = [10, 25, 15, 30, 20]
dict_1 = {key: [value] for key, value in zip(string_list, values)}
dict_df = pd.DataFrame(dict_1, columns=["DictionaryData"])

# Question 4
concat_df = pd.concat([string_df, arr_df, dict_df], axis=1)
