import numpy as np

def slicing(arr):
    '''
    Function takes a 1D array and returns a new array where each element
    is the sum of itself plus the next two elements in the original array
    Params: arr - a 1D array
    Returns: array
    '''
    if arr.size < 3:
        print("Input array must have at least 3 elements")
        return

    extended = np.concatenate((arr, arr[:2]))
    return extended[:-2] + extended[1:-1] + extended[2:]


def main():
    one_d_arr = np.array([0, 2, -5, 8, 9, 1, 4, 8, -9, -3])
    call = slicing(one_d_arr)
    print(call)

main()
