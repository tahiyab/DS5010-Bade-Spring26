import numpy as np

def masking(arr):
    '''
    Function finds and returns the max sum of any 3x3 subarray
    Params: arr - a 10x10 randomly populated (values from 0-100 inclusive) array
    Returns: int
    '''
    max_sum = 0
    for i in range(arr.shape[0] - 2):
        for j in range(arr.shape[1] - 2):
            sub_sum = np.sum(arr[i:i+3, j:j+3])
            if sub_sum > max_sum:
                max_sum = sub_sum
    return max_sum


def main():
    array = np.random.randint(1, 101, size=(10, 10))
    call = masking(array)
    print(call)

main()
