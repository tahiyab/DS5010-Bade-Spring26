import unittest
import numpy as np
from SP3_Tahiya import slicing
from SP4_Tahiya import masking
from SP5_Tahiya import k_closest_points


class TestSlicing(unittest.TestCase):

    def test_normal_case(self):
        arr = np.array([1, 2, 3, 4, 5])
        result = slicing(arr)
        expected = np.array([6, 9, 12, 10, 8])
        np.testing.assert_array_equal(result, expected)

    def test_less_than_three_elements(self):
        arr = np.array([1, 2])
        result = slicing(arr)
        self.assertIsNone(result)


class TestMasking(unittest.TestCase):

    def test_known_max_sum(self):
        arr = np.ones((10, 10))
        result = masking(arr)
        self.assertEqual(result, 9)

    def test_random_shape(self):
        arr = np.random.randint(1, 101, size=(10, 10))
        result = masking(arr)
        self.assertTrue(result > 0)


class TestKClosestPoints(unittest.TestCase):

    def test_multiple_neighbors(self):
        matrix = np.array([[0, 0], [1, 1], [2, 2]])
        query_point = np.array([1, 1])
        result = k_closest_points(query_point, matrix, 2)
        self.assertEqual(result.shape, (2, 2))


if __name__ == "__main__":
    unittest.main()
