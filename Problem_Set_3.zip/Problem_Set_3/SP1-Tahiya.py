import numpy as np

# Question 1.1
p1 = np.random.random((5, 4))

# Question 1.2
p2 = p1[p1 < 0.2] = p1[p1 < 0.2] + 0.2

# Question 1.3
p3 = np.rint(p1.reshape(4, 5) * 100).astype(int)

# Question 1.4
p4 = p3[[0, 1]] = p3[[1, 0]]
print("Question 1.4\n", p4, "\n")

# Question 1.5
b = np.array([[62,78,85,90,97],[97,62,78,85,90],[90,97,62,78,85],[77,99,87,46,82]])
p5 = np.any(np.isin(p4, b))

# Question 1.6
p6 = np.vstack((p4, b))
print("Question 1.6\n", p6, "\n")

# Question 1.7
p7 = values, counts = np.unique(p6, return_counts = True)
print(p7)
