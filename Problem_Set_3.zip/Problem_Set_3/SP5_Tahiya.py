import numpy as np

def k_closest_points(query_point, matrix, k):
    '''
    Purpose: Function calculates Euclidean distances between a query point and
    all points in X, finds and returns the k closest points in X to the query point
    Params: query_point - 1D array with coordnates of , matrix - 2D array of shape (N, 2),
            k - number of closest neighbors 
    Returns: array
    '''
    distances = np.sqrt(np.sum(np.square(matrix - query_point), axis=1))
    indices = np.argsort(distances)[:k]
    return matrix[indices]


def main():
    N = 20
    X = np.random.rand(N, 2)
    query_point = np.array([0.5, 0.5])
    k = 3
    print("Query point:")
    print(query_point)
    print("k closest points:")
    print(k_closest_points(query_point, X, k))

main()
