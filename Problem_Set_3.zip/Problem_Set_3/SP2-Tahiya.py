import numpy as np

# Question 1.1
p1 = np.random.random((5, 4))

# Question 2.1
evens_p1 = np.arange(10, 56, 2)
p1 = np.random.choice(evens_p1, size=16).reshape(4, 4)

# Question 2.2
max_index = np.unravel_index(np.argmax(p1), p1.shape)
student_index = max_index[0]
highest_grade = p1[max_index]
print("Question 2.2\n", "Student Index:", student_index, "Highest Grade:", highest_grade, "\n")

# Question 2.3
sorted_p1 = np.sort(p1)[::-1]
print(sorted_p1)

# Question 2.4
diag_sum = np.sum(np.diagonal(sorted_p1))
diag_sum
