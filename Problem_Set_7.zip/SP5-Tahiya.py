import pandas as pd
import matplotlib.pyplot as plt


df = pd.read_csv("Problem_Set_7/diamonds.csv")
clarities = df["clarity"].unique()

fig, axes = plt.subplots(nrows=len(clarities), ncols=1, figsize=(4, 10))

colors = ["hotpink", "orange", "mediumseagreen", "cornflowerblue",
          "violet", "yellow", "turquoise", "salmon"]

for i, clarity in enumerate(clarities):
    subset = df[df["clarity"] == clarity]

    axes[i].hist(subset["price"], bins=20, color=colors[i % len(colors)])

    axes[i].set_title(f"Price Distribution for Clarity: {clarity}")
    axes[i].set_xlabel("Price")
    axes[i].set_ylabel("Frequency")

plt.tight_layout()

plt.show()
