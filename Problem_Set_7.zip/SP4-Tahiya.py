import pandas as pd
import matplotlib.pyplot as plt


df = pd.read_csv("Problem_Set_7/diamonds.csv")
categories = df["cut"].value_counts()

fig, ax = plt.subplots(figsize=(8, 8))
wedges, text, autotexts = ax.pie(
                                categories.values, 
                                autopct="%1.1f%%", 
                                colors=["hotpink", "orange", "mediumseagreen", "cornflowerblue", "violet"],
                                startangle=90)

ax.legend(categories.index, loc="best")

plt.show()
