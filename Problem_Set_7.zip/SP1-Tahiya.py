import numpy as np
import matplotlib.pyplot as plt


x = np.linspace(-20, 20, 100)
g = x / np.sqrt(1 + x**2)
f = np.exp(x) / (1 + np.exp(x))

fig, ax = plt.subplots(figsize=(10, 10))

ax.plot(x, f, label="f(x) = e^x / (1 + e^x)", color="pink", linewidth=2, linestyle='-')
ax.plot(x, g, label="g(x) = x / sqrt(1 + x^2)", color="green", linewidth=2, linestyle=':')

ax.set_xlabel("x values")
ax.set_ylabel("Function values")
ax.set_title("Graph of f(x) and g(x)")

ax.legend()

plt.savefig("SP1-Tahiya.png")

plt.show()
