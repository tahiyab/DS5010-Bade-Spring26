import pandas as pd
import matplotlib.pyplot as plt


df = pd.read_csv("Problem_Set_7/diamonds.csv")

# Part 2.1

cut_counts = df["cut"].value_counts()
categories = cut_counts.index
values = cut_counts.values

fig, ax = plt.subplots(figsize=(8, 6))
ax.bar(categories, values)

ax.set_xlabel("Cut Quality")
ax.set_ylabel("Number of Diamonds")
ax.set_title("Distribution of Diamonds by Cut")

ax.set_xticks(range(len(categories)))
ax.set_xticklabels(categories)

# Part 2.2

fig, ax = plt.subplots(figsize=(8, 6))
ax.hist(df["x"], bins=20, density=True, color="hotpink")

ax.set_xlabel("Length in mm")
ax.set_ylabel("Frequency")
ax.set_title("Frequency Distribution of Diamonds by Length")

ax.set_xlim(3, 10)

plt.show()
