"""
Inference: 
There is a strong positive correlation between carat size and price.
"""

import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("Problem_Set_7/diamonds.csv")

fig, ax = plt.subplots(figsize=(10, 6))
ax.scatter(df["carat"], df["price"], color="orange", alpha=0.5)

ax.set_xlabel("Carat")
ax.set_ylabel("Price")
ax.set_title("Price vs Carat of Diamonds")

ax.yaxis.grid(True)

ax.text(3, 7000, "Outlier")

plt.show()
