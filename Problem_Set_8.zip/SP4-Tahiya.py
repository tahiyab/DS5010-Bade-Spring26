import seaborn as sns
import matplotlib.pyplot as plt

iris = sns.load_dataset("iris")
print(iris.head())

# Question 1
sns.pairplot(data=iris, vars=["sepal_length", "sepal_width", "petal_length", "petal_width"], hue="species", palette="husl")
plt.show()

# Question 2
'''
Analysis: Petal length and petal width create clear, well-separated clusters between species.
Sepal length and width show more overlap, making them less effective for distinguishing species.
This suggests petal features are more useful for classification.'''

# Question 3
pair_grid = sns.PairGrid(data=iris, vars=["sepal_length","sepal_width","petal_length","petal_width"], hue="species")
pair_grid.map_diag(sns.histplot)
pair_grid.map_upper(sns.scatterplot)
pair_grid.map_lower(sns.kdeplot)
pair_grid.add_legend()
plt.show()
