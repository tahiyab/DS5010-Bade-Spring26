import seaborn as sns
import matplotlib.pyplot as plt

titanic = sns.load_dataset("titanic")
print(titanic.head())

# Question 1
plt.figure(figsize=(10, 6))
sns.violinplot(data=titanic, x="pclass", y="survived", palette="Set2");
plt.show()

plt.figure(figsize=(10, 6))
sns.violinplot(data=titanic, x="adult_male", y="survived", palette="RdPu");
plt.show()
'''
Analysis: Passengers in higher classes (1st class) show higher survival rates than those in lower classes.
Non-adult males (women/children) have significantly higher survival rates than adult males.
This reflects priority rescue patterns during the disaster.'''

# Question 2
sns.jointplot(data=titanic, x="age", y="fare", hue="survived", palette={0: "red", 1: "green"})
plt.show()
'''
Analysis: Just by looking at the graph, people who paid more fare tended to have been more likely to survive
than those who did not. More fare paid and survival was more positively correlated than age and survival.'''

# Question 3
pivot = titanic.pivot_table(values="survived", index="pclass", columns="sex", aggfunc="mean")
print(pivot)
'''
Analysis: Women have significantly higher survival rates than men across all classes. First-class passengers 
have the highest survival rates overall. Third-class males have the lowest survival rates.'''

# Question 4
plt.figure(figsize=(10, 8))
numeric_titanic = titanic[["survived","pclass","age","sibsp","parch","fare","adult_male","alone"]]
corr = numeric_titanic.corr()
sns.heatmap(corr, annot=True, cmap="coolwarm")
plt.title("Correlation Heatmap")
plt.show()
'''
Analysis: The variables most correlated with survival are pclass (negative correlation) and fare (positive correlation).
Higher class and higher fare are associated with higher survival rates.'''
