import seaborn as sns
import matplotlib.pyplot as plt

iris = sns.load_dataset('iris')
print(iris.head())

# Count Plot
fig1 = sns.countplot(data=iris, x="species");
fig1.set_xticks([0, 1, 2])
fig1.set_xticklabels(["Setosa", "Virginica", "Versicolor"])
sns.despine(left=True)
plt.show()

# Histogram
fig2 = sns.histplot(data=iris, x="sepal_length", bins=60, hue="species");
plt.show()

# Bar Plot Mean
plt.figure(figsize=(10, 6))
sns.barplot(data=iris, x="species", y="sepal_length", palette="pastel");
plt.show()

# Bar Plot Std
iris_std = iris.groupby("species")["sepal_length"].std().reset_index()
plt.figure(figsize=(12, 8))
sns.barplot(data=iris_std, x="species", y="sepal_length", palette = "mako");
plt.show()

# Horizontal Box Plot
plt.figure(figsize=(10, 6))
sns.boxplot(data=iris, x="sepal_length", y="species", palette="pastel")
sns.boxplot(data=iris, x="sepal_length", y="species", palette="pastel")
sns.boxplot(data=iris, x="sepal_length", y="species", palette="pastel");
plt.show()

"""
Viginica's box being larger indicates that there is a larger IQR between that species and the other two, 
which suggests greater variability in this variable.
"""
