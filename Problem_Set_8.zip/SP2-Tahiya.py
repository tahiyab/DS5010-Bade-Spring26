import seaborn as sns
import matplotlib.pyplot as plt

mpg = sns.load_dataset("mpg")
print(mpg.head())

# Strip Plot
sns.stripplot(data=mpg, x="model_year", y="mpg", hue="origin", jitter=True, palette="Set2");
plt.show()
'''
Analysis: MPG generally increases over the years. Cars from the USA tend to have lower MPG than those from Japan or Europe.'''

# KDE Plot
plt.figure(figsize=(10, 6))
sns.kdeplot(data=mpg, x="cylinders", y="mpg", fill=True, cmap="coolwarm");
plt.show()
'''
Analysis: Cars with fewer cylinders tend to have higher MPG, while those with more cylinders have lower MPG.
The density seems to be concentrated around lower cylinder counts and higher MPG values.'''

# Scatterplot
plt.figure(figsize=(10, 6))
sns.scatterplot(data=mpg, x="displacement", y="horsepower", hue="origin",palette="Set2",alpha=0.6);
plt.show()
'''
Analysis: There is a strong positive relationship between displacement and horsepower, meaning more cylinders results in
more power. USA carmakers tend to make cars with higher displacement and horsepower values. Japanese and European cars generally 
have smaller engines with less horsepower.'''

# Rug Plot
plt.figure(figsize=(10, 6))
sns.rugplot(data=mpg, x="displacement", y="horsepower", hue="origin", palette="Set2")
plt.show()
