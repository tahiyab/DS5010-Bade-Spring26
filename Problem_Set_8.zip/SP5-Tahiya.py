import seaborn as sns
import matplotlib.pyplot as plt

flights = sns.load_dataset("flights")
print(flights.head())

# Question 1
sns.boxplot(data=flights, x="month", y="passengers", palette="Set2")
plt.title("Frequency of Passenger Flights by Month")
plt.show()

# Question 2
plt.figure(figsize=(12, 6))
sns.lineplot(data=flights ,x="month", y="passengers", hue="year", palette="viridis")
plt.title("Passengers by Month and Year")
plt.show()

# Question 3
avg_month = flights.groupby("month")["passengers"].mean().reset_index()
sns.barplot(data=avg_month, x="month", y="passengers", palette="RdPu")
plt.title("Average Passenger Flights by Month")
plt.show()
'''
Analysis: August and July tend to have the highest average number of passengers.'''

# Question 4
'''
Analysis: Plot used was the same from Question 3. Passenger flights peak in summer months and drop in winter.'''

# Question 5
plt.figure(figsize=(10, 6))
sns.lineplot(x="year", y="passengers", data=flights)
plt.title("Passenger Growth Over Years")
plt.show()
