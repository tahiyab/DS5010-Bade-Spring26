# Note: I renamed this file to SP2_Tahiya because I experienced a problem with accessing it in Problem 3

'''
Difference Between Abstract and Concrete Classes:
An abstract class is one that cannot be used to create objects 
directly and acts as a blueprint for other classes that are beneath it. 
If we visualize a hierarchy of classes, an abstract class would be at the top.
Abstract classes can also contain abstract methods. 
A concrete class is one that can be used to create objects 
directly and can implement the functions that are described in the abstract class.

Classes Inheriting From Another Class:
When a class inherits from another class it takes on the attributes
and methods of the parent class. The child class reuses the existing
code and either builds on or changes the behavior of the parent class.
'''
from abc import ABC, abstractmethod


class Animal(ABC):
    @abstractmethod
    def __init__(self, age, gender):
        """
        Abstract class constructor.
        Parameters - age (int): Age of the animal; gender (str): Gender of the animal
        Returns: None
        """
        self.age = age
        self.gender = gender

    def isMammal(self):
        """
        Prints whether the animal is a mammal.
        Parameters: None
        Returns: None
        """
        print("It is a mammal")

    def mate(self):
        """
        Prints mating behavior.
        Parameters: None
        Returns: None
        """
        print("The animal is mating")
