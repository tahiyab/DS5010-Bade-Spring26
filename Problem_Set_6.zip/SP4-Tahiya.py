from abc import ABC, abstractmethod


class Animal(ABC):

    @abstractmethod
    def speak(self):
        """
        Prints sound of the animal.
        Parameters - None
        Returns - None
        """
        pass


class Dog(Animal):

    def speak(self):
        """
        Prints the sound a dog makes.
        Parameters - None
        Returns - None
        """
        print("Woof!")


class Cat(Animal):

    def speak(self):
        """
        Prints the sound a cat makes.
        Parameters - None
        Returns - None
        """
        print("Meow!")


dog = Dog()
cat = Cat()

dog.speak()
cat.speak()

animals = [Dog(), Cat()]

for animal in animals:
    animal.speak()
