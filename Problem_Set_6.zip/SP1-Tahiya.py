class Order:

    def __init__(self, amounts, numberOfItems):
        self.amounts = amounts
        self.numberOfItems = numberOfItems
    
    def __str__(self):
        return f"This order amounts to ${self.amounts} and contains {self.numberOfItems} items."

    def __gt__(self, other):
        return self.amounts > other.amounts
    
    def __len__(self):
        return self.numberOfItems


order1 = Order(100, 5)
order2 = Order(120, 3)
clean_dir = [item for item in dir(order1) if not item.startswith('_')]
print(clean_dir)
print(order1)
print(order1 > order2)
print(len(order1))
