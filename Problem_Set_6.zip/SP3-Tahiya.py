from SP2_Tahiya import Animal


class Duck(Animal):


    def __init__(self, age, gender, beakColor="yellow"):
        """
        Creates an instance of a Duck object
        Parameters:
            age (int): Age of the duck
            gender (str): Gender of the duck
            beakColor (str): Color of the beak
        Return - None
        """
        super().__init__(age, gender)
        self.beakColor = beakColor


    def swim(self):
        """
        Prints swimming behavior
        Parameters - None
        Returns - None
        """
        print("Duck swims")


    def quack(self):
        """
        Prints quacking behavior
        Parameters - None
        Returns - None
        """
        print("Duck quacks")

    def __str__(self):
        """
        Returns string representation of the Duck.
        Parameters - None
        Returns - str
        """
        return f"This duck is {self.age} year old, is a {self.gender}, and has {self.beakColor} beak."


class Fish(Animal):


    def __init__(self, age, gender, sizeInFt, canEat):
        """
        Creates an instance of a Fish object.
        Parameters:
            age (int): Age of the fish
            gender (str): Gender of the fish
            sizeInFt (int): Size of the fish in feet
            canEat (bool): Whether the fish can eat
        Returns - None
        """
        super().__init__(age, gender)
        self.__sizeInFt = sizeInFt
        self.__canEat = canEat


    def __swim(self):
        """
        Private swim method.
        Parameters - None
        Returns - None
        """
        print("Fish swims")


    def call_swim(self):
        """
        Public method to access private swim method.
        Parameters - None
        Returns - None
        """
        self.__swim()


    def __str__(self):
        """
        Returns string representation of the Fish.
        Parameters - None
        Returns - str
        """
        return f"This fish is {self.age} year old, is a {self.gender}, and is {self.__sizeInFt} ft long. Can eat: {self.__canEat}"


class Zebra(Animal):


    def __init__(self, age, gender, is_wild):
        """
        Creates an instance of a Zebra object.
        Parameters:
            age (int): Age of the zebra
            gender (str): Gender of the zebra
            is_wild (bool): Whether the zebra is wild
        Returns - None
        """
        super().__init__(age, gender)
        self.is_wild = is_wild


    def run(self):
        """
        Prints running behavior.
        Parameters - None
        Returns - None
        """
        print("Zebra runs")


    def __str__(self):
        """
        Returns string representation of the Zebra.
        Parameters - None
        Returns - str
        """
        return f"This zebra is {self.age} year old, is a {self.gender}, and wild status is {self.is_wild}"


duck1 = Duck(1, "male")
duck2 = Duck(2, "female", "yellow")
fish1 = Fish(1, "male", 3, True)
zebra1 = Zebra(4, "female", True)

duck1.isMammal()
duck1.mate()
duck1.swim()
duck1.quack()

duck2.isMammal()
duck2.mate()
duck2.swim()
duck2.quack()

fish1.isMammal()
fish1.mate()
fish1.call_swim()

zebra1.isMammal()
zebra1.mate()
zebra1.run()

print(duck1)
print(duck2)
print(fish1)
print(zebra1)
