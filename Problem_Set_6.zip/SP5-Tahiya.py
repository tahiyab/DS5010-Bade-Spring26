class Store:

    def __init__(self):
        """
        Creates instance of the Store with item prices, empty inventory, and zero balance.
        Parameters - None
        Returns - None
        """
        self.balance = 0
        self.prices = {"apple": 2, "banana": 1}
        self.inventory = {"apple": 0, "banana": 0}

    def add_inventory(self, item, quantity):
        """
        Adds inventory for an item if it exists in the store.
        Parameters - item (str), quantity (int)
        Returns - None
        """
        if item in self.inventory:
            self.inventory[item] += quantity
        else:
            print(f"{item} is not sold in this store")

    def sell_item(self, item, quantity):
        """
        Sells an item if enough inventory exists and updates balance.
        Parameters - item (str), quantity (int)
        Returns - None
        """
        if item not in self.inventory:
            print(f"{item} is not sold in this store")
        elif self.inventory[item] < quantity:
            print(f"Not enough {item} in inventory")
        else:
            self.inventory[item] -= quantity
            self.balance += self.prices[item] * quantity

    def get_balance(self):
        """
        Returns the current store balance.
        Parameters - None
        Returns - balance (int)
        """
        return self.balance

    def get_inventory(self):
        """
        Returns the current inventory.
        Parameters - None
        Returns - inventory (dict)
        """
        return self.inventory


store = Store()

store.add_inventory("apple", 10)
store.add_inventory("banana", 5)
store.add_inventory("pear", 2)

store.sell_item("apple", 3)
store.sell_item("banana", 7)

print("Balance:", store.get_balance())
print("Inventory:", store.get_inventory())
