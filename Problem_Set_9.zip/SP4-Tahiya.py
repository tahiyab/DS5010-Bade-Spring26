import matplotlib.pyplot as plt 
import imageio.v3 as iio
from scipy import ndimage

image = iio.imread('Problem_Set_9/grayscale_page.png')

# Rotated Image
plt.imshow(image)
print(f"Image Type: {type(image)}")
print(f"Image Shape: {image.shape}")
print(f"Image D Type: {image.dtype}")

rotated_image = ndimage.rotate(image, angle=60, reshape=False)

plt.figure(figsize=(10, 5))

plt.subplot(1, 2, 1)
plt.imshow(image)
plt.title("Original Image")

plt.subplot(1, 2, 2)
plt.imshow(rotated_image)
plt.title("Rotated Image");

plt.tight_layout()
plt.show()

# Sobel Image

sobel_image = ndimage.sobel(image, axis=1)

plt.figure(figsize=(10, 5))

plt.subplot(1, 2, 1)
plt.imshow(image)
plt.title("Original Image")

plt.subplot(1, 2, 2)
plt.show(sobel_image)
plt.title("Image With Sobel Filter");

plt.tight_layout()
plt.show()
