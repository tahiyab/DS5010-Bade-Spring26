from scipy.integrate import quad
from scipy.integrate import dblquad
import numpy as np

# Function 1
f1 = lambda x: np.exp(-x**2)
integral, integral_error = quad(f1, -np.inf, np.inf)

# Function 2
f2 = lambda x: np.exp(-2*x)
integral, integral_error = quad(f2, 0, np.inf)

# Function 3
f3 = lambda y, x: x**3 * y
lower_y = lambda x: 0
upper_y = lambda x: np.sqrt(1 - 8 * x**3)
integral, integral_error = dblquad(f3, 0, 0.5, lower_y, upper_y)

# Function 4
f4 = lambda y, x: x * y
lower_y = lambda x: 0
upper_y = lambda x: 1
integral, integral_error = dblquad(f4, 0, 1, lower_y, upper_y)
