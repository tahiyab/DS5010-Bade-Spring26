import matplotlib.pyplot as plt 
import imageio.v3 as iio
import numpy as np

page = iio.imread('imageio:page.png')

plt.imshow(page)
print(f"Image Type: {type(page)}")
print(f"Image Shape: {page.shape}")
print(f"Image D Type: {page.dtype}")

vertical_flip = np.flip(page, axis=0)

plt.figure(figsize=(10, 5))

plt.subplot(1, 2, 1)
plt.imshow(page)
plt.title("Original Image")

plt.subplot(1, 2, 2)
plt.imshow(vertical_flip)
plt.title("Image Flipped Upside Down")

plt.tight_layout()
plt.show()
