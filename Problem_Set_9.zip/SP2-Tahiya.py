import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import interp1d

x = np.array([0,1,2,3,4])
y = np.array([1,3,2,5,7])

interp_func = interp1d(x, y, kind='quadratic')

new_x = np.linspace(0, 4, 10)
new_y = interp_func(new_x)

plt.plot(x, y, 'o', label='Original Points')
plt.plot(new_x, new_y, '-', label='Quadratic Interpolation')
plt.legend()
plt.show()
