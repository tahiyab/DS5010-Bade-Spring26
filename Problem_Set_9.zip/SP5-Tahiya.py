import numpy as np
from scipy.optimize import minimize

def f(v):
    x, y = v
    return np.abs(x + 3*y - 6) + np.abs(2*x - y)

x0 = [1, 1]

constraints = [
    {'type': 'ineq', 'fun': lambda v: v[0] + v[1] - 5},
    {'type': 'ineq', 'fun': lambda v: v[1]},
    {'type': 'ineq', 'fun': lambda v: v[0]}
]

res = minimize(f, x0, constraints=constraints)

print("Solution (x, y):", res.x)
print("Minimum value:", res.fun)
